# StSolaVault

Personal 6-digit PIN vault for photos and passwords.

Mobile-first PWA with glassmorphism UI.

## Features
- 6-digit PIN lock (first launch sets the PIN)
- Photos: upload, view, delete (stored locally)
- Passwords: add / edit / delete / copy
- Clear glass tiles + black text
- Works offline as PWA (Add to Home Screen)

## How to use right now
1. Upload all these files to your GitHub repo `StSolaVault`
2. Deploy to Cloudflare Pages (or any static host)
3. Open the site on your phone → Share → Add to Home Screen

## Data storage
Currently uses `localStorage` so everything stays on device.
Later you can swap the storage layer to Cloudflare D1 + R2 if you want cloud backup.

## Files
- `index.html` – main app
- `css/styles.css` – glass styles
- `js/app.js` – all logic
- `public/background.jpg` – your cosmic background
- `manifest.json` + `sw.js` – PWA support
